package com.koreait.first;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView/*메소드*/(R.layout.activity_main);/*R은 리소스를 담고있다라는 뜻*/
        /*R에 마우스를 올리면 final class라고 뜨는데 이건*/
        /*정의 안했는데 쓸 수 있다는 말은 super로 부터 상속을 받았다.*/
        /*static인지 instance인지 알 수 없다. static 안적혀 있어서..*/
        /*setContentView 뭔화면을 지정해줄지..?*/
    }

    //이벤트 연결(event binding) 버튼 클릭시 실행될 메소드
    public void clkBtn(View/*모든 위젯값을 받을 수 있다 최상위 개체*/ v) {
        // v.getText(); getText가 써지는 이유는 부모개체가 갖고있어서..
        //EditText btn = (EditText)v; 이렇게 적으면 에러터진다. 에딧텍스트와 버튼은 형제관계이기 때문에
        Button btn = (Button)v;
        String btnText = (String)btn.getText(); // 형변환 해야한다. 왠지는 나중에 알려주신다고..
        Toast.makeText(this, btnText + "를 클릭했어요."
                , Toast.LENGTH_LONG).show();
    }

    public void ddd(View v) {
        TextView tv = (TextView) v;

        CharSequence cs = tv.getText() + "f를 클릭했어요";
        String str = (String)cs;

       /* Toast toast = Toast.makeText(this, tv.getText(), Toast.LENGTH_LONG);
        toast.show(); 이 문장을 줄여 놓은게 밑에 문장이다
        //한문장에서 .이 두개 있다 그럼 뭔가 리턴해준다는 뜻이다. 뭘 리턴해주냐
        //리턴타입(왼쪽이 파라미터 구현부, 오른쪽이 파라미터 리턴타입이 토스트...토스트 객체 주소값이 나온다.
        //
        */

        Toast.makeText(this,  tv.getText(), Toast.LENGTH_LONG).show();
        //스태틱 메소드이다. 왜인가요? : 왜인가요... 두 개의 사용방법이 다르다..가능하면 스태틱을 붙여라
        //일단 메소드는 맞음.왜냐 ()가 있기 때문. 앞에 Toast는 앞이 대문자.. 이건 클래스란 뜻
        //클래스는 이미 메모리에 올라가 있는 상태다
        //클래스를 불러오면 스태틱쓴다. 클래스 안불러오는 경우 즉 스태틱이 아닌경우 new를 써야한다.
        //LENGTH_LONG 이렇게 전부 대문자면 상수이다. 거기다 앞에 Toast. 같이 뭐가 붙어있으면
        //static이 붙는다 .어디서 받아온거라서 이미 메모리에 올라가있음
        //public static final int LENGTH_LONG = 1121212;
        //랭스롱, 랭스쇼트는 노출시간 결정해준다.
        //네이밍에 쓸 수 있는 특수문자 ($) 랑 (_) 두 개


    }
}